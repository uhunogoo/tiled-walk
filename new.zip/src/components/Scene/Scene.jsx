import * as THREE from 'three/webgpu';

import React from 'react';
import { Physics } from '@react-three/rapier';
import { Canvas, extend } from '@react-three/fiber';
import { KeyboardControls, OrbitControls } from '@react-three/drei';

import World from '@components/World/World';
import Player from '@components/Player/Player';
import { useControls } from 'leva';

extend( THREE );

function Scene() {
  const [ frameloop, setFrameloop ] = React.useState( "never" );
  const { DEBUG } = useControls('Physycs', { DEBUG: false });

  const map = React.useMemo(() => [
    { name: 'forward', keys: [ 'ArrowUp', 'KeyW' ] },
    { name: 'backward', keys: [ 'ArrowDown', 'KeyS' ] },
    { name: 'leftward', keys: [ 'ArrowLeft', 'KeyA' ] },
    { name: 'rightward', keys: [ 'ArrowRight', 'KeyD' ] },
    { name: 'run', keys: [ 'ShiftLeft' ] },
    { name: 'jump', keys: [ 'Space' ] }
  ], []);

  return (
    <KeyboardControls map={ map }>
      <Canvas
        style={{ position: 'fixed', top: 0, left: 0, height: "100vh", width: "100vw" }}
        camera={{ position: [0, 12, 0], fov: 75 }}
        frameloop={ frameloop }
        gl={(props) => {
          const renderer = new THREE.WebGPURenderer({
            powerPreference: "high-performance",
            antialias: true,
            alpha: false,
            stencil: false,
            shadowMap: true,
            ...props,
          });
          renderer.init().then(() => {
            setFrameloop("always");
          });
          return renderer;
        }}
      >
        <ambientLight intensity={0.5} />
        <directionalLight position={[0, 10, 5]} intensity={1} />
        
        <React.Suspense fallback={null}>
          <Physics debug={ DEBUG } gravity={[0, -9.81, 0]}>
            <Player />
            <World />
          </Physics>
        </React.Suspense>

        {/* <OrbitControls makeDefault /> */}

      </Canvas>
    </KeyboardControls>
  )
}

export default Scene;